//
//  SearchByFloorTableViewCell.swift
//  AR
//
//  Created by 최유진 on 17/11/2019.
//  Copyright © 2019 M-33. All rights reserved.
//

import UIKit

class SearchByFloorTableViewCell: UITableViewCell {

    

}
